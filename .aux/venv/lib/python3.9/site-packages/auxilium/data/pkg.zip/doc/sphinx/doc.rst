
.. module:: <name>
    :noindex:

-----------------
API Documentation
-----------------

.. toctree::
    :glob:

    ./api/*
